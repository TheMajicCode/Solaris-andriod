package K5;

import android.health.connect.datatypes.DataOrigin;
import android.health.connect.datatypes.Metadata;

/* JADX INFO: loaded from: /workspace/scratch/7a1f5a13b137/reconstruction-work/code601-classes.dex */
public abstract /* synthetic */ class B {
    public static /* bridge */ /* synthetic */ DataOrigin a(Metadata metadata) {
        return metadata.getDataOrigin();
    }
}
