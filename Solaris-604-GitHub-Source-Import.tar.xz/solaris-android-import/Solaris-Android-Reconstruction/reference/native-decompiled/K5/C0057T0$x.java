package K5;

import kotlin.jvm.functions.Function1;

/* JADX INFO: renamed from: K5.T0$x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /workspace/scratch/7a1f5a13b137/reconstruction-work/code601-classes.dex */
public final class C0057T0$x implements Function1 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    final /* synthetic */ T0 f1621f;

    public C0057T0$x(T0 t6) {
        this.f1621f = t6;
    }

    public final Object b(Object[] objArr) {
        J3.l.f(objArr, "<destruct>");
        W2.s sVar = (W2.s) objArr[0];
        T0 t6 = this.f1621f;
        T0.F(t6, sVar, new C0048T0$o(t6));
        return p137u3.A.f16167a;
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Object q(Object obj) {
        return b((Object[]) obj);
    }
}
